'use strict';
(function(g){
  const M=g.MSOS4,E=g.MSOSEngines;if(!M?.ui||!E?.Coordinator||!E?.Modification||!E?.Evidence||!E?.RacePace)return;
  const UI=M.ui,U=M.util,B=M.boardEngine={build:'v4-board-whiteboard-20260901a-clean-prescription'};
  const text=v=>String(v??'').replace(/\s+/g,' ').trim(),esc=v=>U?.escape?U.escape(v):text(v),clock=s=>U?.clock?U.clock(Number(s)):text(s);
  const short=v=>text(v).replace(/\bFreestyle\b/gi,'Fr').replace(/\bBackstroke\b/gi,'Bk').replace(/\bBreaststroke\b/gi,'Br').replace(/\bButterfly\b/gi,'Fly').replace(/\bRegeneration\b/gi,'REG').replace(/\bDevelopment\b/gi,'DEV').replace(/\bOverload\b/gi,'OL').replace(/\bThreshold\b/gi,'THR').replace(/\bClearance\b/gi,'CL').replace(/\bRace Pace\b/gi,'RP').replace(/\bDescend\b/gi,'Desc').replace(/\bStroke Count\b/gi,'SC');
  const preferred=a=>text(a?.board_name||a?.boardName||a?.nickname||a?.preferred_name||a?.preferredName);
  const firstDisplay=first=>/^Matthew$/i.test(first)?'Matt':first;
  const nameParts=a=>text(a?.full_name).split(/\s+/).filter(Boolean);
  const suffixSource=a=>{const p=nameParts(a),surname=p.length>1?p.at(-1):'',fallback=text(a?.squad)||String(a?.id||'').replace(/[^a-z0-9]/gi,'');return surname||fallback||'?';};
  function uniqueSuffix(a,group){const src=suffixSource(a),others=group.filter(x=>x?.id!==a.id).map(suffixSource);for(let n=1;n<=src.length;n++){const p=src.slice(0,n).toUpperCase();if(others.every(s=>s.slice(0,n).toUpperCase()!==p))return p;}return src.toUpperCase();}
  function name(a,pool=[]){if(!a)return'?';const nick=preferred(a);if(nick)return nick;const parts=nameParts(a),first=parts[0]||'?',same=pool.filter(x=>x?.id!==a.id&&!preferred(x)&&nameParts(x)[0]?.toLowerCase()===first.toLowerCase());if(!same.length)return firstDisplay(first);const group=[a,...same];return`${firstDisplay(first)} ${uniqueSuffix(a,group)}`;}
  B.name=name;
  const zoneShort=z=>({Regeneration:'REG',Development:'DEV',Overload:'OL',Threshold:'THR',Clearance:'CL'})[z]||short(z);
  function itemDistance(n){if(!n)return 0;if(n.kind==='set')return Math.max(1,Number(n.reps)||1)*(Number(n.distance)||0);if(n.kind==='group')return Math.max(1,Number(n.rounds)||1)*(n.items||[]).reduce((s,x)=>s+itemDistance(x),0);return 0;}
  const blockDistance=b=>(b?.items||[]).reduce((s,x)=>s+itemDistance(x),0),sessionDistance=s=>(s?.blocks||[]).reduce((n,b)=>n+blockDistance(b),0);
  function compactPattern(item){const p=item?.repPattern||[];if(!p.length)return'';const groups=[];for(const x of p){const z=zoneShort(x.zone),last=groups.at(-1);if(last&&last.z===z)last.n++;else groups.push({z,n:1});}return groups.map(x=>`${x.n>1?x.n+' ':''}${x.z}`).join(' / ');}
  function compactSequence(item){const p=item?.pattern||[];if(!p.length)return'';return p.map(x=>`${Math.max(1,Number(x.count)||1)} ${short(x.text||'')}`.trim()).join(' / ');}
  function compactRace(item){const rows=item?.repInstructions||[];if(!rows.some(x=>x.raceIntent))return'';const non=rows.filter(x=>!x.raceIntent),race=rows.filter(x=>x.raceIntent),bits=[];if(non.length)bits.push(non.length===1?`#${non[0].rep} ${short(non[0].label||'Build')}`:`#${non[0].rep}-${non.at(-1).rep} ${short(non[0].label||'Build')}`);if(race.length){const d=race[0].raceIntent?.distance||item?.raceIntent?.distance||'';bits.push(`#${race[0].rep}${race.length>1?`-${race.at(-1).rep}`:''} RP${d}`);}return bits.join(' · ');}
  function composition(item){const c=item?.composition||[];return c.length?c.map(x=>`${x.distance} ${short(x.text)}`).join(' / '):'';}
  function repIntervals(item){const seen=new Map();for(const s of [item?.raw,item?.text,...(item?.cues||[]),...(item?.repInstructions||[]).map(x=>x?.label||'')].map(text).filter(Boolean)){const re=/#\s*(\d+)\s*@\s*(\d{1,2})[:.]([0-5]\d)\b/ig;let m;while((m=re.exec(s)))seen.set(Number(m[1]),{rep:Number(m[1]),seconds:Number(m[2])*60+Number(m[3])});}return[...seen.values()].sort((a,b)=>a.rep-b.rep);}
  function variableRepIntervals(item){const rows=repIntervals(item);return rows.length>1&&new Set(rows.map(x=>x.seconds)).size>1;}
  // 16 Oct 2026 (Andy's Fri AM session): "@0:30" showed as "@ 30" -- the time formatter drops minutes under 60s, which
  // is right for a swim time (30.12) but wrong for a send-off. Send-offs always read m:ss.
  function sendClock(sec){const n=Math.round(Number(sec));if(!Number.isFinite(n)||n<=0)return clock(sec);return`${Math.floor(n/60)}:${String(n%60).padStart(2,'0')}`;}
  function repIntervalText(item){const rows=repIntervals(item);return rows.length>1?rows.map(x=>`#${x.rep} @ ${sendClock(x.seconds)}`).join(' · '):'';}
  function inlineIntent(item){let s=short(item?.raw||item?.text).replace(/^\d+\s*[x×]\s*\d+(?:\.5)?\s*/i,'').replace(/^\d+(?:\.5)?\s*/,'');const st=short(E.Evidence.stroke(item?.stroke||''));if(st)s=s.replace(new RegExp(`^${st.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')}\\b\\s*`,'i'),'');s=s.replace(/(?:@|on)\s*\d{1,2}[:.]\d{2}\b/ig,'').replace(/\b(?:Regeneration|REG|Development|DEV|Overload|OL|Threshold|THR|Clearance|CL)\b(?:\s+to\s+\b(?:Regeneration|REG|Development|DEV|Overload|OL|Threshold|THR|Clearance|CL)\b)?/ig,'').replace(/\b(?:Fins|Paddles|Pull|Bands|Snorkel)\b/ig,'').replace(/^[\s·,+/-]+|[\s·,+/-]+$/g,'');return /#\s*1\b/i.test(s)?s:'';}
  function tidyCues(item){const skipIntervals=new Set(repIntervals(item).map(x=>x.rep)),intent=inlineIntent(item),hasRest=Number(item?.restSeconds)>0;let rows=(item?.cues||[]).map(short).filter(Boolean).filter(s=>{const m=s.match(/^#\s*(\d+)\s*@\s*\d{1,2}[:.]\d{2}\b/i);if(m&&skipIntervals.has(Number(m[1])))return false;if(intent&&short(s)===intent)return false;/* 19 Oct 2026: "Makeup: 100 Free / 100 Reverse IM / 50 IM Order" repeated the composition already shown */{const c=composition(item);if(c&&short(s).replace(/^make[- ]?up\s*:\s*/i,'').toLowerCase()===c.toLowerCase())return false;}/* 13 Oct 2026: '#1-3 Dev'-style lines are already shown as the compact zone pattern (3 DEV / 3 OL ...) */if((item?.repPattern||[]).length&&/^#\s*\d+(?:\s*[-–]\s*\d+)?\s+(?:reg|regen|regeneration|dev|development|ol|overload|at|thr|threshold|cl|clearance)\b\.?\s*$/i.test(s))return false;if(hasRest&&(/\b\d{1,3}\s*(?:s|sec|seconds?)\s*(?:r|rest)\b/i.test(s)||/\b(?:r|rest)\b\s*(?:[·:=-]\s*)?\d{1,3}\s*(?:s|sec|seconds?)?\b/i.test(s)))return false;return true;});let s=rows.join(' · ');s=s.replace(/Build through each \d+/ig,'Build').replace(/Strong final 25 Fr/ig,'Last 25 strong').replace(/Attack last turn and underwater/ig,'Attack last turn').replace(/Hold the line and finish strong/ig,'Finish strong');return s;}
  // Real coaching failure this fixes (Andy's real 18 Sept session, live Board screenshots): "300 Choice Swim
  // @ 5:15" rendered as headline "300 @ 5:15" with sub-line "Swim @ 5:15", and "200 Choice" + "Remove Fins"
  // rendered as "200" / "Remove Fins" -- the word "Choice" vanished from BOTH the headline (workLabel, below)
  // and here, every time. E.Evidence.stroke() only ever returns the literal string 'Choice' when the coach
  // explicitly typed the word "choice" as the stroke -- an athlete with no stroke mentioned at all gets ''
  // (falsy), never 'Choice' as a silent default -- so there was never a real "meaningless default" case for
  // this special-casing to be protecting; it was simply deleting a deliberate coaching instruction (choice of
  // stroke under race conditions is real information, not a null value). Stop treating 'Choice' differently
  // from any other authored stroke here.
  // Real coaching failure this fixes (Andy, live, 21 Sept 2026, from his own screen: McKenzie's rep-condensed
  // kick set showing "8×50 Fr Kick @ 1:10 / Desc 1-4 / 5-8 · Desc 1—3" -- BOTH the machine-regenerated
  // per-rep-group breakdown AND the coach-authored cue at once). engines/bridge.js's preserveRepeatingDescent()
  // (wired up earlier this same day -- see tests/prescription-bridge-descent-preservation-20260921.cjs) fixed
  // the Board's headline text/cue to correctly show the coach's ORIGINAL authored "Desc 1-3" instead of a
  // wrongly-regenerated one, restoring it into item.cues/raw/text and marking the item
  // item.authoredPatternPreserved=true -- but it deliberately never touches item.repPattern itself (that
  // array still reflects Modification.adaptItem's own condensed-reps regeneration, e.g. 12->8 reps
  // regrouping "Desc 1-3" into two 4-rep groups). compactPattern() below reads that same still-regenerated
  // repPattern independently of tidyCues()'s item.cues, and cueText()'s bits array pushed both without
  // regard for whether one had just been corrected -- so the fixed, authored cue and the still-regenerated
  // pattern description both rendered, concatenated, instead of the fix's correction replacing the
  // regenerated one on screen. Fixed by treating authoredPatternPreserved as authoritative: once the bridge
  // has restored the coach's real cue, the machine-regenerated per-rep-group pattern text is suppressed
  // (item.cues already carries the one correct, authored description) -- race/composition/repeat/interval
  // cues are untouched, since none of those are what adaptItem regenerates against the condensed rep count.
  // See tests/board-cue-double-up-authored-pattern-20260921.cjs.
  function cueText(item){const patPreserved=!!item?.authoredPatternPreserved,pat=patPreserved?'':compactPattern(item),race=compactRace(item),seq=compactSequence(item),comp=composition(item),repeat=short(item?.repeatBreakdownCue||''),intervals=repIntervalText(item),cues=tidyCues(item),rest=Number(item?.restSeconds)>0?`Rest · ${Number(item.restSeconds)} sec`:'',bits=[];if(pat)bits.push(pat);else if(race)bits.push(race);if(comp)bits.push(comp);if(repeat)bits.push(repeat);else if(seq)bits.push(seq);if(intervals)bits.push(intervals);if(cues)bits.push(cues);if(rest)bits.push(rest);if(bits.length)return[...new Set(bits.filter(Boolean))].join(' · ');if(item?.zone||(item?.repPattern||[]).length||inlineIntent(item))return'';const rest2=short(item?.raw||item?.text).replace(/^\d+\s*[x×]\s*\d+(?:\.5)?\s*/i,'').replace(/^\d+(?:\.5)?\s*/,'').replace(/^(Fr|Bk|Br|Fly|IM|Free|Back|Breast)\b\s*/i,'').replace(/^(Pull|Upper-body)\b\s*/i,'').replace(/^·\s*/, '');return repeatsHeadline(item,rest2)?'':rest2;}
  // 16 Oct 2026: "8×12.5 Bands MAX @ 0:30" was followed by "Bands Only MAX @0:30" -- the same line twice. A fallback
  // cue made only of words the headline already shows (plus send-off and filler words) is dropped.
  function repeatsHeadline(item,cue){const head=workLabel(item).toLowerCase(),c=String(cue||'').toLowerCase().replace(/(?:@|on)\s*\d{1,2}[:.]\d{2}\b/g,' ').replace(/@\s*\d+\b/g,' ');
    const words=c.match(/[a-z0-9.]+/g)||[];if(!words.length)return true;const stop=new Set(['only','and','the','with','m','of']);
    return words.every(w=>stop.has(w)||head.includes(w)||(/^\d+m?$/.test(w)&&head.includes(w.replace(/m$/,'')+'m')));}
  // Real coaching failure this fixes: Andy authored "3x50 1 build, 1@200pace, 1 max @ 1:30" -- a per-rep
  // breakdown where only the THIRD rep is max effort, reps 1-2 are build/200-pace -- but the Board's bold
  // headline read "3×50 MAX @ 1:30", claiming the whole set was max effort. Root cause: the MAX check below
  // only ever tested whether the literal word "MAX" appeared ANYWHERE in the raw line, with no regard for
  // whether it described the whole set (correct for something like "8 x 25 MAX Sprint") or only one rep out of
  // several in an explicit comma-separated per-rep list (wrong -- that's exactly this case). Detected via the
  // same shape Andy actually types: strip the leading "R x D" header, then check whether at least two of the
  // remaining comma-separated segments each open with their own bare rep count ("1 build", "1@200pace", "1
  // max") -- that pattern only occurs when the coach is assigning efforts per rep, never when describing the
  // set as a whole.
  function repEffortSegments(raw){const stripped=text(raw).replace(/^\d+\s*[x×]\s*\d+(?:\.5)?\s*/i,''),parts=stripped.split(',').map(s=>s.trim()).filter(Boolean);return parts.length<2?[]:parts;}
  function isPerRepEffortList(raw){const parts=repEffortSegments(raw);return parts.length>=2&&parts.filter(p=>/^\d+\s*[@a-z]/i.test(p)).length>=2;}
  function workLabel(item){const reps=Math.max(1,Number(item?.reps)||1),d=Number(item?.distance)||0,raw=short(item?.raw||item?.text),st=short(E.Evidence.stroke(item?.stroke||'')),eq=(item?.equipment||[]).map(short).join('+'),intent=inlineIntent(item),variable=variableRepIntervals(item);if(/Upper-body equivalent/i.test(raw))return`${reps}×${d} Upper-body${item?.cycleSeconds&&!variable?` @ ${sendClock(item.cycleSeconds)}`:''}`;let label=`${reps>1?reps+'×':''}${d}`;if(st)label+=` ${st}`;else if(/#\s*1F\b/i.test(raw))label+=' #1F';else if(/#\s*1\s*Stroke\b/i.test(raw))label+=' #1 Stroke';if(/\bUnderwater\b/i.test(raw)&&!/\bUnderwater\b/i.test(label))label+=' Underwater';if(eq&&!new RegExp(`\\b${eq}\\b`,'i').test(label))label+=` ${eq}`;if(/\bKick\b/i.test(raw)&&!/\bKick\b/i.test(label))label+=' Kick';if(/\bPull\b/i.test(raw)&&!/Pull/i.test(label))label+=' Pull';const partMax=raw.match(/\b(\d{1,3})\s*m?\s+max\b/i);if(partMax&&Number(partMax[1])>0&&Number(partMax[1])<d&&!isPerRepEffortList(raw)){if(!/MAX/i.test(label))label+=` ${Number(partMax[1])}m MAX`;}else if(/\bMAX\b/i.test(raw)&&!/MAX/i.test(label)&&!isPerRepEffortList(raw))label+=' MAX';if(item?.zone&&!(item?.repPattern||[]).length)label+=` ${zoneShort(item.zone)}`;if(intent&&!label.toLowerCase().includes(intent.toLowerCase()))label+=` ${intent}`;if(label===`${reps>1?reps+'×':''}${d}`&&!item?.zone&&!(item?.repPattern||[]).length&&!(item?.pattern||[]).length&&!(item?.composition||[]).length&&!item?.raceIntent){const words=bareWords(raw);if(words)label+=` ${words}`;}if(item?.cycleSeconds&&!variable)label+=` @ ${sendClock(item.cycleSeconds)}`;return label;}
  // A bare distance line keeps its own short description in the headline ("200 Easy", "200 sculling"), instead of
  // the word disappearing into the small text or being dropped.
  function bareWords(raw){const r=text(raw).replace(/^\d+\s*[x×]\s*\d+(?:\.5)?\s*/i,'').replace(/^\d+(?:\.5)?\s*m?\b\s*/i,'').replace(/(?:@|on)\s*\d{1,2}[:.]\d{2}\b/ig,'').replace(/\b\d+\s*s(?:ec(?:s|onds)?)?\s*(?:R|rest)\b/ig,'').replace(/[()]/g,' ').replace(/\s+/g,' ').trim();
    if(!r||/\d/.test(r)||r.length>22||r.split(' ').length>3)return'';if(/\b(?:REG|DEV|OL|THR|CL|Regeneration|Development|Overload|Threshold|Clearance|Pace|RP|Race|Desc|Build|Neg)\b/i.test(r))return'';return r;}
  function targetIntent(item){return !!(item?.targetSeconds||item?.zone||(item?.repPattern||[]).length||item?.raceIntent||(item?.repInstructions||[]).some(x=>x.raceIntent));}
  function strokeChangeable(item){const raw=text(item?.raw||item?.text),st=E.Evidence.stroke(item?.stroke||'');if(/\b(?:Kick|Underwater|FOB)\b/i.test(raw)&&!/#\s*1\b/i.test(raw))return false;return ['Freestyle','Backstroke','Breaststroke','Butterfly','IM'].includes(st)||/#\s*1\b/i.test(raw)||!!(item?.zone||(item?.repPattern||[]).length);}
  function timingIntent(item){return targetIntent(item)||(Number(item?.cycleSeconds)>0&&strokeChangeable(item));}
  const STROKE_SHORT={Freestyle:'Fr',Backstroke:'Bk',Breaststroke:'Br',Butterfly:'Fly',IM:'IM'};
  function targetAtom(seconds,sendOff){const a=clock(seconds);return sendOff?`${a}/${sendClock(sendOff)}`:a;}
  function targetSummary(r){if(!r||r.status==='none')return'';if(r.status==='ok')return targetAtom(r.seconds,r.sendOff);if(r.status==='fallback')return[`HR ${r.hr||''}`,r.sr?`SR ${r.sr}`:''].filter(Boolean).join(' · ');if(r.status==='missing')return short(r.message||'Target needed');if(r.status==='pattern'){const mixed=new Set((r.rows||[]).map(x=>x.stroke).filter(Boolean)).size>1,seen=new Map();for(const x of r.rows||[]){const k=`${mixed?(STROKE_SHORT[x.stroke]||x.stroke)+' ':''}${zoneShort(x.zone)}`,v=Number(x.seconds)>0?targetAtom(x.seconds,x.sendOff):[x.hr?`HR ${x.hr}`:'',x.sr?`SR ${x.sr}`:''].filter(Boolean).join(' ')||'T400 needed';if(!seen.has(k))seen.set(k,v);}return[...seen].map(([k,v])=>`${k} ${v}`).join(' · ');}if(r.status==='pattern_fallback'){const mixed=new Set((r.rows||[]).map(x=>x.stroke).filter(Boolean)).size>1,seen=new Map();for(const x of r.rows||[]){const k=`${mixed?(STROKE_SHORT[x.stroke]||x.stroke)+' ':''}${zoneShort(x.zone)}`,v=[x.hr?`HR ${x.hr}`:'',x.sr?`SR ${x.sr}`:''].filter(Boolean).join(' ');if(!seen.has(k))seen.set(k,v);}return[...seen].map(([k,v])=>`${k} ${v}`).join(' · ');}if(r.status==='rep_race'){const rows=r.rows||[],bits=[],non=rows.filter(x=>x.status==='none'),ok=rows.filter(x=>x.status==='ok'),missing=rows.filter(x=>x.status==='missing');if(non.length)bits.push(non.length===1?`#${non[0].rep} ${short(non[0].label||'Build')}`:`#${non[0].rep}-${non.at(-1).rep} Build`);if(ok.length){const groups=[];for(const x of ok){const v=targetAtom(x.seconds,x.sendOff),last=groups.at(-1);if(last&&last.v===v)last.end=x.rep;else groups.push({start:x.rep,end:x.rep,v});}for(const x of groups)bits.push(`#${x.start}${x.end>x.start?'-'+x.end:''} ${x.v}`);}if(missing.length)bits.push([...new Set(missing.map(x=>short(x.message||'PB needed')))].join(' / '));return bits.join(' · ');}return'';}
  function present(){return UI.presentAthletes?.()||[];}
  function modified(){const p=present(),ids=new Set(p.map(a=>a.id)),m=UI.modifiedAthletes?.();if(Array.isArray(m)&&m.length)return m.filter(a=>ids.has(a.id));return p.filter(a=>Number(E.Modification.profile(a,M.state).ratio)<.98||text(a.modifications));}
  function activeOverride(session,item,ath){return(M.state?.adaptationOverrides||[]).find(r=>r.sessionId===session.id&&r.itemId===item.id&&r.athleteId===ath.id&&r.active!==false)||null;}
  function selectedStroke(session,item,ath){return activeOverride(session,item,ath)?.patch?.stroke||'';}
  // Real coaching failure this fixes (Phase 3, 10 Sept 2026): a stroke change Jordan proposes that doesn't
  // match the evidence is held as a pending proposal (see engines/modification-edit.js's resolveStrokeGate)
  // rather than applied or silently discarded -- but that's worthless if Andy would only ever see it by
  // happening to reopen that exact swimmer's modification editor. This small flag on the Board itself is what
  // actually delivers "flag it for you": visible the moment Andy looks at the modified-swimmer row, not buried.
  function pendingStrokeFlag(session,item,ath){const p=activeOverride(session,item,ath)?.pendingStrokeProposal;return p?`<button class="msos-pending-flag" data-msos-mod-edit="${esc(item.id)}:${esc(ath.id)}" title="${esc(p.proposedBy?.name||'Assistant coach')} proposed ${esc(p.stroke)} — ${esc(p.reason)}" aria-label="Flagged stroke change for ${esc(name(ath,present()))}">⚑</button>`:'';}
  function contextualStroke(session,item,ath){const raw=text(item?.raw||item?.text),formOnly=/#\s*1F\b/i.test(raw);try{return M.performanceEngine?.selectStrokeForContext?.(ath,item,M.state,session,{formOnly})||null;}catch{return null;}}
  function strokeInfo(session,item,ath){
    const override=selectedStroke(session,item,ath);if(override)return{stroke:E.Evidence.stroke(override),source:'coach',detail:'Coach-selected stroke'};
    const raw=text(item?.raw||item?.text),ambiguous=/#\s*1/i.test(raw);
    if(ambiguous){const c=contextualStroke(session,item,ath);if(c?.stroke){const s=text(c.source).toLowerCase();let source='auto';if(/recent coach/.test(s))source='recent';else if(c?.bestEvent?.stroke==='IM'||/medley|stroke balance|\bim\b/.test(s))source='im';else if(/highest ranked|pb|wa/.test(s))source='pb';return{stroke:E.Evidence.stroke(c.stroke),source,detail:c.source||'Contextual performance selection'};}}
    if(item?.raceIntent||(item?.repInstructions||[]).some(x=>x.raceIntent)||ambiguous){const v=E.RacePace.resolveStroke(item,ath,M.state,session?.identity?.course||'SCM','')||'Auto';return{stroke:v,source:ambiguous?'auto':'race',detail:ambiguous?'Automatic contextual stroke':'Race-intent stroke'};}
    const st=E.Evidence.stroke(item?.stroke||'');if(st)return{stroke:st,source:'authored',detail:'Coach-authored stroke'};if(item?.zone||(item?.repPattern||[]).length)return{stroke:'Freestyle',source:'aerobic',detail:'Aerobic default stroke'};return{stroke:st||'Auto',source:'auto',detail:'Automatic stroke'};
  }
  function displayStroke(session,item,ath){return strokeInfo(session,item,ath).stroke;}
  function strokeLabel(session,item,ath){const info=strokeInfo(session,item,ath),base=info.stroke==='Auto'?'Auto':short(info.stroke),tag=({coach:'C',recent:'REC',im:'IM',pb:'PB'})[info.source];return tag?`${base} ·${tag}`:base;}
  function athleteLink(a,pool=[]){return`<button class="msos-name" data-msos-ath="${esc(a.id)}">${esc(name(a,pool))}</button>`;}
  function strokePill(session,item,a){const info=strokeInfo(session,item,a),lab=strokeLabel(session,item,a);return`<button class="msos-stroke-pill" data-msos-stroke="${esc(item.id)}:${esc(a.id)}" aria-label="Change stroke for ${esc(name(a,present()))}" title="${esc(info.detail||'Resolved stroke')}">${esc(lab)}</button>`;}
  // setStroke used to live here, called only by the dead [data-msos-stroke] bubble-phase handler removed from
  // bind() below (see that removal's comment). engines/board-state.js has its own, more complete setStroke
  // (also supports the Times-panel's targetOnly refresh) which is the one actually in effect. Removed rather
  // than left as an orphaned duplicate with zero callers.
  function targetPanel(_session,item,_groupAth){return`<div class="msos-target-panel" data-msos-panel="${esc(item.id)}"><section><label>TIMES</label><div class="msos-target-matrix" data-msos-target-matrix><span class="msos-none">Loading targets…</span></div></section></div>`;}
  function captures(session,{itemId='',blockId='',sessionOnly=false}={}){return(M.state?.captures||[]).filter(c=>c?.session_id===session?.id&&(sessionOnly?(!c.item_id&&!c.block_id):(itemId?c.item_id===itemId:(blockId?c.block_id===blockId&&!c.item_id:false)))).sort((a,b)=>String(a.created_at||'').localeCompare(String(b.created_at||'')));}
  function captureWho(c){const ids=[...(c?.athlete_ids||[])];if(c?.athlete_id&&!ids.includes(c.athlete_id))ids.push(c.athlete_id);if(!ids.length)return'GROUP';const pool=present();if(ids.length===1){const a=(M.state?.athletes||[]).find(x=>x.id===ids[0]);return a?name(a,pool):'Swimmer';}return`${ids.length} swimmers`;}
  function evidenceStrip(rows=[]){if(!rows.length)return'';return`<div class="msos-evidence-strip">${rows.map(c=>{const t=text(c.capture_type||'note').toLowerCase(),icon=t==='video'?'▶':t==='photo'?'▣':t==='voice'?'♪':'✎',label=t==='video'?'Video':t==='photo'?'Photo':t==='voice'?'Voice':'Note',title=text(c.text_content||c.title||''),detail=[captureWho(c),title||label].filter(Boolean).join(' · ');return`<button class="msos-evidence-thumb ${t}" data-msos-capture="${esc(c.id)}" aria-label="Open ${esc(label)} capture"><span>${icon}</span><small>${esc(detail)}</small></button>`;}).join('')}</div>`;}
  function modGroupKey(item){return JSON.stringify([Math.max(1,Number(item?.reps)||1),Number(item?.distance)||0,E.Evidence.stroke(item?.stroke||''),Number(item?.restSeconds)||0,Number(item?.cycleSeconds)||0,[...(item?.equipment||[])].map(text).sort(),workLabel(item),cueText(item),text(item?.adaptiveMode||''),!!item?.adaptivePending]);}
  function modPerson(session,item,m,mods,actual){const a=m.a,target=m.showTiming?`<span class="msos-mod-target" data-msos-mod-item="${esc(item.id)}" data-msos-mod-ath="${esc(a.id)}">${esc(m.target?targetSummary(m.target):(actual?.cycleSeconds?`@ ${clock(actual.cycleSeconds)}`:'…'))}</span>`:'';return`<span class="msos-mod-person">${athleteLink(a,mods)}${pendingStrokeFlag(session,item,a)}<button class="msos-mod-edit" data-msos-mod-edit="${esc(item.id)}:${esc(a.id)}" aria-label="Edit ${esc(name(a,mods))} modification">Edit</button>${m.showTiming?strokePill(session,item,a):''}${target}</span>`;}
  // Real coaching failure this fixes (Andy's own words, 13 Sept 2026): "all the explanation of why on the mod
  // side don't need to show n the board" -- the modified-column reason text (e.g. "67% load fallback · no
  // fair performance comparator", "Load fallback · 600→400 single continuous work") was added on 9 Sept so a
  // modification that legitimately makes no structural change reads differently from "the pipeline did
  // nothing" (see architecture/RUNTIME_AUDIT_20260909.md §2), and evidenceProvenance() (11 Sept, the
  // session-methodology "Jordan sees evidence" work) appended a second, even longer evidence-citation clause
  // to that same line. Both are exactly the clutter Andy is describing live poolside on the Board -- he still
  // gets the swimmer's name, the modified numbers/label, and the short cue text describing the actual work,
  // just not the paragraph of reasoning behind it. The underlying data is not deleted: modification.js still
  // computes and attaches adaptationReason (and relativeStimulusEvidence/relativeStimulusPlan) to every
  // adapted item exactly as before, so engines/session-methodology.js's own separate flagged-for-review
  // summary (which reads adaptationReason directly off the adapted item, not off anything board.js renders)
  // is entirely unaffected by removing it from this live view.
  // 19 Oct 2026 (Andy: "Charlotte not right esp that kick set, doubling up again"): a plain "Kick" set gets a stroke
  // worked out only so a target can be calculated (Freestyle by default). The Board showed that as "Fr Kick" beside
  // the squad's "Kick" and so listed Charlotte's work again even where it was identical. The headline shows the work as
  // written; a stroke the coach chose (stroke pill) or a #1 stroke still shows.
  function shownItem(item,actual){const r=actual?.strokeResolution;if(r&&r.source!=='coach'&&!/#\s*1/.test(text(item?.raw||item?.text))&&!E.Evidence.stroke(item?.stroke||''))return{...actual,stroke:item?.stroke||''};return actual;}
  B.shownItem=shownItem;
  function modCell(session,item,mods){
    if(!mods.length)return'';const groups=new Map();
    for(const a of mods){const prescription=E.Coordinator.prescription?.(session,item,a,M.state),actual=shownItem(item,prescription?.item||E.Modification.adaptItem(item,a,M.state,session)),changed=!E.Modification.samePrescription(item,actual),needsTarget=targetIntent(actual),showTiming=timingIntent(actual);if(!changed&&!showTiming)continue;const key=modGroupKey(actual);if(!groups.has(key))groups.set(key,{actual,members:[]});groups.get(key).members.push({a,needsTarget,showTiming,target:prescription?.target||null});}
    return[...groups.values()].map(group=>{const {actual,members}=group,cue=cueText(actual),people=members.map(m=>modPerson(session,item,m,mods,actual)).join('');
      return`<div class="msos-mod-row" data-msos-mod-group="${esc(item.id)}"><div class="msos-mod-top">${people}</div><b>${esc(workLabel(actual))}</b>${cue?`<small class="msos-mod-cue">${esc(cue)}</small>`:''}</div>`;}).join('');
  }
  // No longer called from modCell (see the removal above) -- kept as the shared pure formatter that
  // tests/session-methodology-20260911.cjs extracts directly by source text for its own "Jordan sees
  // evidence" logic (session-methodology.js's per-decision evidence citation is the SAME shape this
  // produces). Left in place rather than deleted so that feature's own test coverage isn't disturbed by a
  // Board-display-only change.
  function evidenceProvenance(actual){
    const plan=actual?.relativeStimulusPlan,ev=actual?.relativeStimulusEvidence;
    if(plan?.athleteSeconds&&plan?.referenceSeconds)return`${plan.evidenceKind==='t400'?'T400':'PB'} evidence: ${clock(plan.athleteSeconds)} vs squad median ${clock(plan.referenceSeconds)} (${plan.referenceCount} swimmer${plan.referenceCount===1?'':'s'})`;
    if(ev?.athleteSeconds&&ev?.referenceSeconds)return`${ev.kind==='t400'?'T400':'PB'} evidence: ${ev.stroke?`${ev.stroke} `:''}${clock(ev.athleteSeconds)} vs squad median ${clock(ev.referenceSeconds)} (${ev.referenceCount} swimmer${ev.referenceCount===1?'':'s'})`;
    return'';
  }
  function setRow(session,item,groupAth,mods){const intent=timingIntent(item),canOpen=intent&&groupAth.length>0,id=esc(item.id),open=canOpen&&M.state?.settings?.boardExpandedTargetId===item.id,ev=evidenceStrip(captures(session,{itemId:item.id}));return`<div class="msos-work-row" data-item="${id}"><div class="msos-group-cell"><div class="msos-work-head"><b>${esc(workLabel(item))}</b>${canOpen?`<button class="msos-times-btn" data-msos-times="${id}">${open?'Close':'Times'}</button>`:''}</div>${cueText(item)?`<small>${esc(cueText(item))}</small>`:''}${ev}</div><div class="msos-mod-cell">${modCell(session,item,mods)}</div>${canOpen&&open?targetPanel(session,item,groupAth):''}</div>`;}
  function nodeRows(session,node,groupAth,mods){if(node?.kind==='set')return setRow(session,node,groupAth,mods);if(node?.kind==='group')return`<div class="msos-rounds"><div class="msos-round-label">${Math.max(1,Number(node.rounds)||1)} ROUNDS${node.label?` · ${esc(short(node.label))}`:''}</div>${modRounds(session,node,mods)}${(node.items||[]).map(x=>nodeRows(session,x,groupAth,mods)).join('')}</div>`;if(node?.kind==='cue')return`<div class="msos-board-cue">${esc(short(node.text||node.raw))}</div>`;
    // Real coaching failure this fixes: any node kind this function doesn't specifically handle above (chiefly
    // 'component' -- a numeric-led line the parser provisionally tags for a composition merge that then fails
    // its sum-match/explicit-marker check, e.g. a genuine short ladder entry, or a coach remark that happens to
    // start with a number) fell through to a bare `return ''` and vanished from the Board with no trace --
    // matching "disappears unless bracketed" (architecture/RUNTIME_AUDIT_20260909.md §6). An authored line must
    // always render as SOMETHING, even when its node kind isn't one this renderer has a dedicated case for yet.
    if(node){const fallback=short(String(node.raw||node.text||(Number(node.distance)>0?`${node.distance}m`:'')||'').trim());if(fallback)return`<div class="msos-board-cue" data-msos-unclassified-kind="${esc(node.kind||'')}">${esc(fallback)}</div>`;}
    return'';}
  // 19 Oct 2026: modified swimmers now do fewer rounds of an unchanged round set (Modification.adaptGroup); say so.
  function modRounds(session,node,mods){if(!mods.length||!E.Modification.adaptGroup)return'';const by=new Map();for(const a of mods){let g=null;try{g=E.Modification.adaptGroup(node,a,M.state,session);}catch{}const r=Number(g?.rounds),base=Math.max(1,Number(node.rounds)||1);if(!g||!Number.isFinite(r)||r===base)continue;if(!by.has(r))by.set(r,[]);by.get(r).push(a);}
    return[...by.entries()].map(([r,list])=>`<div class="msos-mod-row msos-mod-rounds"><div class="msos-mod-top">${list.map(a=>athleteLink(a,mods)).join('')}</div><b>${r} ROUNDS</b></div>`).join('');}
  function blockCode(b){const t=text(b?.type||b?.title).toLowerCase();if(/warm.?up/.test(t))return'WU';if(/pre/.test(t))return'PRE';if(/main/.test(t))return'MAIN';if(/post/.test(t))return'POST';if(/warm.?down|cool/.test(t))return'WD';return text(b?.title).slice(0,4).toUpperCase();}
  function blockHtml(session,b,groupAth,mods){const ev=evidenceStrip(captures(session,{blockId:b.id}));return`<section class="msos-board-block" data-block="${esc(b.id)}"><header><div><small>${esc(blockCode(b))}</small><h2>${esc(b.title||'Set')}</h2></div><b>${blockDistance(b).toLocaleString()}m</b><span>${mods.length?`MOD ${mods.length}`:''}</span></header>${ev}<div class="msos-board-grid">${(b.items||[]).map(x=>nodeRows(session,x,groupAth,mods)).join('')}</div></section>`;}
  function route(view){if(M.navigationEngine?.go)return M.navigationEngine.go(view,{restore:false});if(M.nav?.show)return M.nav.show(view,{restoreScroll:false});M.state.settings=M.state.settings||{};M.state.settings.view=view;M.storageEngine?.saveUi?.(M.state);UI.renderCurrent?.();}
  function findItem(session,id){let hit=null;const walk=items=>{for(const n of items||[]){if(n?.id===id){hit=n;return;}if(n?.kind==='group')walk(n.items);if(hit)return;}};for(const b of session?.blocks||[]){walk(b.items);if(hit)break;}return hit;}
  function rememberTargetAnchor(btn){const row=btn.closest?.('.msos-work-row');M.state.settings.boardTargetAnchor={itemId:btn.dataset.msosTimes,top:row?.getBoundingClientRect?.().top??null,y:window.scrollY||0};}
  function restoreTargetAnchor(host){const a=M.state?.settings?.boardTargetAnchor;if(!a)return;M.state.settings.boardTargetAnchor=null;requestAnimationFrame(()=>{const selector=`[data-item="${String(a.itemId).replace(/"/g,'\\"')}"]`,row=host.querySelector(selector);if(row&&Number.isFinite(Number(a.top))){window.scrollBy(0,row.getBoundingClientRect().top-Number(a.top));}else window.scrollTo(0,Number(a.y)||0);});}
  function paintFinishAction(session){const b=document.querySelector('[data-sticky-finish]');if(!b)return;if(session?.finish){b.textContent='Finished ✓';b.disabled=true;b.title=`Finished · ${Number(session.finish.actualDistance||sessionDistance(session)).toLocaleString()}m saved locally`;}else{b.textContent='Finish';b.disabled=false;b.title='Finish session';}}
  function bind(host,session){
    host.querySelectorAll('[data-msos-times]').forEach(btn=>btn.onclick=()=>{if(M.boardStateEngine?.openPanel)return M.boardStateEngine.openPanel(btn);M.state.settings=M.state.settings||{};rememberTargetAnchor(btn);M.state.settings.boardExpandedTargetId=M.state.settings.boardExpandedTargetId===btn.dataset.msosTimes?'':btn.dataset.msosTimes;M.storageEngine?.saveUi?.(M.state);UI.renderBoard();});
    host.querySelectorAll('[data-msos-ath]').forEach(btn=>btn.onclick=e=>{e.stopPropagation();M.state.settings=M.state.settings||{};M.state.settings.selectedAthleteId=btn.dataset.msosAth;M.state.settings.selectedSwimmerId=btn.dataset.msosAth;route('athletes');});
    // A per-button bubble-phase onclick for [data-msos-stroke] used to be wired here too, duplicating
    // engines/board-state.js's document-level CAPTURE-phase listener for the same selector. That capture-phase
    // listener calls e.stopImmediatePropagation() before this bubble-phase handler could ever run, so this was
    // permanently dead code -- unlike the [data-msos-times] handler just above, which explicitly checks for and
    // delegates to M.boardStateEngine first (real, intentional fallback if board-state.js is ever unavailable),
    // this stroke handler had no such guard and could never fire under normal operation. Removed rather than
    // left in place as an accident of DOM event-phase ordering -- board-state.js's strokeMenu() is the sole,
    // already-active implementation (and a superset: it also covers [data-msos-fast-stroke] for the Times
    // panel). See architecture/RUNTIME_AUDIT_20260909.md §7 and tests/board-stroke-binding-dedupe-20260909.cjs.
    host.querySelector('[data-msos-mode]')?.addEventListener('click',()=>{M.state.settings.boardFocusMode=M.state.settings.boardFocusMode===false;M.state.settings.boardExpandedTargetId='';M.storageEngine?.saveUi?.(M.state);UI.renderBoard();});
    host.querySelectorAll('[data-msos-block]').forEach(btn=>btn.onclick=()=>{M.state.settings.boardFocusMode=true;M.state.settings.boardExpandedTargetId='';M.state.settings.boardBlockBySession=M.state.settings.boardBlockBySession||{};M.state.settings.boardBlockBySession[session.id]=btn.dataset.msosBlock;M.storageEngine?.saveUi?.(M.state);UI.renderBoard();});
    host.querySelector('[data-msos-roll]')?.addEventListener('click',()=>route('roll'));host.querySelector('[data-msos-t400]')?.addEventListener('click',()=>route('times'));host.querySelector('[data-msos-swimmers]')?.addEventListener('click',()=>route('athletes'));
  }
  function context(session){const athletes=present(),mods=modified(),modIds=new Set(mods.map(a=>a.id)),groupAth=athletes.filter(a=>!modIds.has(a.id));M.state.settings=M.state.settings||{};M.state.settings.boardBlockBySession=M.state.settings.boardBlockBySession||{};let active=workBlocks(session).find(b=>b.id===M.state.settings.boardBlockBySession[session.id]);if(!active)active=workBlocks(session).find(b=>b.type==='main_set')||workBlocks(session)[0];if(active)M.state.settings.boardBlockBySession[session.id]=active.id;return{athletes,mods,groupAth,active};}
  function afterPaint(host){requestAnimationFrame(()=>{M.boardStateEngine?.hydrateVisibleModTargets?.();M.captureUI?.hydrateBoardEvidence?.(host);});}
  // Real coaching failure this fixes (Andy's own words, 10 Sept 2026, Phase 4 -- "proper TV live-times
  // broadcast"): the TV view has never shown a single time, on any device, ever -- it renders only the
  // workout board (see renderTV below), completely independent of engines/live-training-authority.js's
  // relay actually delivering anything. Fixing the cross-device transport (that file's L.publishCloud/
  // L.pullCloud) does nothing visible without this: it only makes M.state.timedSets/trainingTestResults
  // update correctly in the background. This panel is what actually puts times on the screen -- the most
  // recent finished timed-set reps (X.saveLive, the Times-view stopwatch) and T400 anchor tests for
  // whichever session the TV has open, newest first. Deliberately read-only (no data-msos-* handlers): a TV
  // is a passive display, never an input device -- editing stays on the coach's own Times/Board view.
  function liveTimesRows(session){
    const ts=(M.state?.timedSets||[]).filter(x=>x.session_id===session.id).map(x=>({...x,msosLiveKind:'timed_set'}));
    const tt=(M.state?.trainingTestResults||[]).filter(x=>x.session_id===session.id).map(x=>({...x,msosLiveKind:'t400'}));
    return[...ts,...tt].sort((a,b)=>String(b.created_at||'').localeCompare(String(a.created_at||''))).slice(0,8);
  }
  function liveTimeRow(row){
    const ath=(M.state?.athletes||[]).find(a=>a.id===row.athlete_id),who=ath?name(ath,present()):'Swimmer';
    if(row.msosLiveKind==='t400')return`<div class="msos-live-row"><b>${esc(who)}</b><span>400 ${esc(row.pool_course||'')}</span><b>${esc(clock(row.result_seconds))}</b></div>`;
    const label=[row.distance?`${row.distance}${row.stroke?' '+short(E.Evidence.stroke(row.stroke)):''}`:'',short(row.set_label||'')].filter(Boolean).join(' · ');
    return`<div class="msos-live-row"><b>${esc(who)}</b><span>${esc(label)}</span><b>${esc(clock(row.best))} best</b></div>`;
  }
  function liveTimesPanel(session){const rows=liveTimesRows(session);if(!rows.length)return'';return`<section class="msos-tv-live"><header><small>LIVE TIMES</small></header>${rows.map(liveTimeRow).join('')}</section>`;}
  // 19 Oct 2026: a heading line with no sets under it ("KICK DEVELOPMENT / BODY POSITION") is the session's theme, not a 0m block.
  function workBlocks(session){return(session?.blocks||[]).filter(b=>(b.items||[]).length);}
  /* 20 Oct 2026: an empty WARM-DOWN / PRE-SET etc. heading is an unwritten section, not the session theme -- it showed "Warm-down" under the title. */function themeLines(session){const STRUCT=/^(?:warm_up|pre_set|main_set|post_set|warm_down)$/;return(session?.blocks||[]).filter(b=>!(b.items||[]).length&&!STRUCT.test(String(b.type||''))).map(b=>text(b.title)).filter(Boolean);}
  B.workBlocks=workBlocks;B.themeLines=themeLines;
  function render(){const host=document.querySelector('#boardView'),session=M.currentSession?.();if(!host)return;if(!session){host.innerHTML='<div class="empty">No session selected.</div>';paintFinishAction(null);return;}const {athletes,mods,groupAth,active}=context(session),focus=M.state.settings.boardFocusMode!==false,blocks=focus&&active?[active]:workBlocks(session),title=session.identity?.title||`${session.identity?.dayPart||''} · ${(session.identity?.squads||[]).join(' + ')}`||'Session',sev=evidenceStrip(captures(session,{sessionOnly:true})),finished=session.finish,delivered=Number(finished?.actualDistance)||sessionDistance(session);host.className='view msos-whiteboard-engine';host.innerHTML=`<div class="msos-board-top"><div><small>${focus?'CURRENT SET':'WHOLE SESSION'}${finished?' · FINISHED ✓':''}</small><h1>${esc(title)}</h1>${themeLines(session).length?`<small class="msos-board-theme">${esc(themeLines(session).join(' · '))}</small>`:''}</div><b>${finished?`${delivered.toLocaleString()}m ✓`:sessionDistance(session).toLocaleString()+'m'}</b></div>${finished?`<div class="context-note msos-board-finished"><b>FINISHED ✓</b> · ${delivered.toLocaleString()}m delivered · saved locally</div>`:''}${sev}<div class="msos-board-quick"><button data-msos-roll>Roll · ${athletes.length}</button><button data-msos-t400>T400 / Times</button><button data-msos-swimmers>Swimmers</button></div><div class="msos-board-nav"><button data-msos-mode>${focus?'WHOLE':'SET'}</button>${workBlocks(session).map(b=>`<button data-msos-block="${esc(b.id)}" class="${focus&&b.id===active?.id?'active':''}">${esc(blockCode(b))}</button>`).join('')}</div>${blocks.map(b=>blockHtml(session,b,groupAth,mods)).join('')}`;bind(host,session);paintFinishAction(session);if(M.state?.settings?.view==='board')host.classList.add('active');restoreTargetAnchor(host);afterPaint(host);}
  function renderTV(){const host=document.querySelector('#tvView'),session=M.currentSession?.();if(!host)return;if(!session){host.innerHTML='<div class="empty">No session selected.</div>';M.tvDisplay?.paint?.();return;}const {mods,groupAth,active}=context(session),title=session.identity?.title||'Session',finished=session.finish,delivered=Number(finished?.actualDistance)||sessionDistance(session);host.className='view msos-tv-board-engine';host.innerHTML=`<div class="msos-tv-top"><h1>${esc(title)}${finished?' · FINISHED ✓':''}</h1><b>${finished?`${delivered.toLocaleString()}m ✓`:sessionDistance(session).toLocaleString()+'m'}</b></div>${liveTimesPanel(session)}${active?blockHtml(session,active,groupAth,mods):''}`;bind(host,session);if(M.state?.settings?.view==='tv')host.classList.add('active');afterPaint(host);M.tvDisplay?.paint?.();}
  UI.renderBoard=render;UI.renderTV=renderTV;B.render=render;B.renderTV=renderTV;B.targetSummary=targetSummary;B.workLabel=workLabel;B.cueText=cueText;B.modCell=modCell;B.displayStroke=displayStroke;B.strokeInfo=strokeInfo;B.strokeLabel=strokeLabel;B.selectedStroke=selectedStroke;B.findItem=findItem;B.evidenceStrip=evidenceStrip;B.paintFinishAction=paintFinishAction;B.modGroupKey=modGroupKey;B.targetIntent=targetIntent;B.timingIntent=timingIntent;B.repIntervals=repIntervals;B.liveTimesRows=liveTimesRows;B.liveTimesPanel=liveTimesPanel;B.blockCode=blockCode;B.blockDistance=blockDistance;B.sessionDistance=sessionDistance;B.present=present;B.modified=modified;
})(globalThis);